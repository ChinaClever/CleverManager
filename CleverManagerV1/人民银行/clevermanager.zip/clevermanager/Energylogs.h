#pragma once
#include "afxcmn.h"
#include "MyListCtrl.h"
#include "afxdtctl.h"
#include "afxwin.h"

// CEnergylogs �Ի���

class CEnergylogs : public CDialog
{
	DECLARE_DYNAMIC(CEnergylogs)

public:
	CEnergylogs(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CEnergylogs();

// �Ի�������
	enum { IDD = IDD_ENERGY_LOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	CMyListCtrl m_list;
	virtual BOOL OnInitDialog();
	void insertList();
	CDateTimeCtrl tm1;
	CDateTimeCtrl tm2;
	void put_record(CString start_time,int start_a_energy,int start_b_energy,CString end_time,int end_a_energy,int end_b_energy,CString logname);
	void put_record_output(CString start_time,int start_a_energy,int start_b_energy,CString end_time,int end_a_energy,int end_b_energy,CString logname);
	int year_ret(CString str_year);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	CComboBox m_device_ip;
	CComboBox m_device_num;
	CComboBox m_type;
	CComboBox m_data;
	afx_msg void OnCbnSelchangeCombo4();
	void SetCabinet(CString type);
	void put_record_energy(void);
	int get_room_energy(CString name,CString time,int change);
	int get_cabinet_energy(CString name,CString time,int change);
	int get_ip_energy(CString ip,int num,CString time);
};
