#pragma once

class CFileLogEdit
{
public:
	CFileLogEdit(void);
	~CFileLogEdit(void);
	void mapCabinRead(void);
	void mapCabinWrite(int mapnum);
};
